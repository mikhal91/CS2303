#include "calcGrades.h"
#include <stdio.h>


/*
Calculates the average of the grades in the array
Also prints out the highest and lowest in the array
 */



int averageGrade(int grades[], int numgrades)
{
  int i;
  double grade = 0;
  int low = 100;
  int high = 0;

  for(i = 0; i < numgrades; i++)
    {
      (grades[i] < low) ? low = grades[i] : 1;
      (grades[i] > high) ? high = grades[i] : 1;
      grade += grades[i];
    }

  grade = (double)grade / (double)numgrades;
  printf("Grade: %f\n High: %d\n Low: %d\n", grade, high, low);
  return 0;
}
