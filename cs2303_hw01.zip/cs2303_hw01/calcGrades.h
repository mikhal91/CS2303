#ifndef CALCGRADES_H
#define CALCGRADES_H

int averageGrade(int grades[], int numgrades);
#endif
